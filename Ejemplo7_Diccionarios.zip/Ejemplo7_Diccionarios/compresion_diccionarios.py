# Ejemplo 1
# crear un diccionario donde :
#       - la clave es el indice de la lista
#       - el valor es la letra
lista = ['a', 'e', 'i', 'o', 'u']
indices = {idx:lista[idx]  for idx in range(len(lista))}
print(indices)

indices2 = {indice: letra  for indice, letra in enumerate(lista)}
print(indices2)


# Ejemplo 2
# crear un diccionario con numeros del 1 al 5 y sus cuadrados
numeros = {num:num**2 for num in range(1,6)}
print(numeros)