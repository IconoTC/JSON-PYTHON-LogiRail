# diccionarios: los elementos son clave:valor
# No tienen indices, se accede a través de la clave
# A partir de la version 3.7 se garantiza el orden de entrada
# Las claves no se pueden repetir, se sobreescribe el valor
# Los valores si se pueden repetir
# Se crean utilizando {}

alumnos = {'Juan': 6.4, 'Maria': 8.3, 'Luis': 6.4, 'Adolfo': 7.1, 'Maria': 9.3}
print(type(alumnos)) # dict
print(alumnos)

# Crear un diccionario vacio
vacio = {}
vacio = dict()

# Mostrar las claves: nombres de los alumnos
print(alumnos.keys())

# Mostrar los values: notas de los alumnos
print(alumnos.values())

# Mostrar los items
print(alumnos.items())

# Operadores de pertenencia: in y not in
print("Maria" in alumnos)
print("Jorge" not in alumnos)

# Acceso a los elementos por clave
print("Nota de Luis:", alumnos['Luis'])
#print("Nota de Luis:", alumnos['Luisssssssssssss']) # KeyError: 'Luisssssssssssss'

print("Nota de Luis:", alumnos.get('Luis'))
print("Nota de Luis:", alumnos.get('Luissssssssssss')) # None

# Borrar un elemento
del alumnos['Adolfo']
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Modificar el valor de un elemento
alumnos['Pepito'] = 5
print(alumnos)

# Otra forma de agregar o modificar elementos del diccionario
alumnos.update({'Paco': 8})
print(alumnos)

# Recorrer un diccionario
for alum in alumnos: # Solo me devuelve la clave
    print(alum, alumnos[alum])
    
for alum in alumnos.items(): # cada alum es una tupla (nombre, nota)
    print(alum)
    
for clave, valor in alumnos.items():
    print(clave, "->", valor)
    
# Otras formas de crear diccionarios
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)
alumnos = dict([('Juan', 6.4), ('Maria', 8.3), ('Luis', 6.4), ('Adolfo', 7.1)])