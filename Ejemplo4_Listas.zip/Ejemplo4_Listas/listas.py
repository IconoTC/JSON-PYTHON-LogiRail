# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones podemos tener datos de distinto tipo
# permite tener elementos duplicados
# se crean con []

list1 = ["Maria", "Perez", 20, "soltera", "sin hijos"]
list2 = ["estudiante", "medicina", 28010]

# mostrar las listas por consola
print(list1)
print(list2)

# crear una lista vacia
lista_vacia = []
lista = list()

# unir listas
lista = list1 + list2  # el orden es importante
print(lista)
lista = list2 + list1
print(lista)

# longitud de la lista
print("Longitud:", len(lista))

# Acceso a los elementos de una lista
# indice positivo comienza por el primero, por la izquierda
# indice negativo comienza por el final, por la derecha
print(lista[2]) # 28010
print(lista[-2]) # soltera

# Agregar elementos al final -> append
lista.append("morena")
print(lista)

# Agregar elementos en una determinada posicion -> insert
lista.insert(0, 1.70)
print(lista)

# Agregar varios elementos a la vez -> extend
lista.extend([1,2,3]) # los elementos tienen que ir en una coleccion
print(lista)

# Eliminar un elemento de la lista
del lista[0]
print(lista)

# Modificar un elemento
lista[-5] = "1 hijo"
print(lista)

''' slices [begin:stop:step] '''
# Mostrar todos los elementos de la lista
print(lista[:])

# Mostrar los ultimos 4 elementos
print(lista[-4:])

# Mostrar del tercero al sexto
print(lista[2:6]) # el ultimo no entra

# Mostra del sexto al tercero
print(lista[5:1:-1])

# Mostrar todos los elementos con orden inverso
print(lista[::-1])

# Mostrar todos los elementos con orden inverso de 2 en 2
print(lista[::-2])

# Mostrar todos los elementos de 2 en 2
print(lista[::2])
