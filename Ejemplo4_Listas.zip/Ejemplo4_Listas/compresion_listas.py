# Ejemplo 1
lista_palabras = ['casa', 'mesa', 'manzana', 'pijama']
longitud_palabras = []  # [4,4,7,6]

for palabra in lista_palabras:
    longitud_palabras.append(len(palabra))
print(longitud_palabras)

''' compresion de listas '''
longitud_palabras = [len(palabra) for palabra in lista_palabras]
print(longitud_palabras)


# Ejemplo 2
num_pares = []

for num in range(0,12):
    if num % 2 == 0:
        num_pares.append(num)
print(num_pares)

''' compresion de listas '''
num_pares = [num for num in range(0,12) if num % 2 == 0]
print(num_pares)