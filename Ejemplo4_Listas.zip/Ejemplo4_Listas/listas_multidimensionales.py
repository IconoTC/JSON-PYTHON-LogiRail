# listas de 2 dimensiones
matriz = [ [2,7,4], [8,1,6], [3,9,5] ] # 2 indices (fila, columna)

'''
2 7 4
8 1 6
3 9 5
'''

# Recorrer una matriz de 2 dimensiones (2 bucles)
for fila in matriz:
    for num in fila:
        print(num, end=" ")
    print()
    
# suma de la digonal (2 + 1 + 5) 
suma = 0
for fila in range(len(matriz)):   # 0,1,2
    for col in range(len(matriz[fila])):
        if fila == col:
            suma += matriz[fila][col]
print("Suma diagonal:", suma)