import json
import requests

new_alumno = {
        "id": 6,    # si no poneis el id os lo genera automaticamente
        "nombre": "Pepito",
        "apellido": "Perez",
        "nota": 2.7,
        "repetidor": True
      }

try:
    respuesta = requests.post("http://localhost:3000/alumnos", data=json.dumps(new_alumno))
    
    # Vuelvo a consultar el nuevo alumnos
    #nuevo = requests.get("http://localhost:3000/alumnos/6")
    # no funciona porque a pesar de crear el alumno 6 en alumnos.json
    # se necesita parar y arrancar el servidor de nuevo para que detecte los cambios
except:
    print("Ha ocurrido un error")
else:
    print("Alumno creado")
    