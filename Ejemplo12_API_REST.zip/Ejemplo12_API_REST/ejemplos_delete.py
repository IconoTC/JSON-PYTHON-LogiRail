import json
import requests

try:
    respuesta = requests.delete("http://localhost:3000/alumnos/6")
except:
    print("Ha ocurrido un error")
else:
    print(respuesta.json())