import requests

# Consultar todos los alumnos
try:
    respuesta = requests.get("http://localhost:3000/alumnos")
except:
    print("Ha ocurrido un error")
else:
    if respuesta.status_code == requests.codes.ok:
        print(respuesta.json())
finally:
    print("----- FIN -----")
 
    
# Consultar todos los alumnos ordenados por nota
# http://servidor:puerto/recurso?_sort=propiedad
try:
    respuesta = requests.get("http://localhost:3000/alumnos?_sort=nota")
except:
    print("Ha ocurrido un error")
else:
    if respuesta.status_code == requests.codes.ok:
        print(respuesta.json())
finally:
    print("----- FIN -----")
 

# Consultar todos los alumnos ordenados por nota descendente
# http://servidor:puerto/recurso?_sort=-propiedad
try:
    respuesta = requests.get("http://localhost:3000/alumnos?_sort=-nota")
    # Otra forma
    # respuesta = requests.get("http://localhost:3000/alumnos", params={"_sort":"-nota"}
except:
    print("Ha ocurrido un error")
else:
    if respuesta.status_code == requests.codes.ok:
        print(respuesta.json())
finally:
    print("----- FIN -----") 


# Consultar todos los alumnos repetidores
try:
    respuesta = requests.get("http://localhost:3000/alumnos?repetidor=true")
except:
    print("Ha ocurrido un error")
else:
    if respuesta.status_code == requests.codes.ok:
        print(respuesta.json())
finally:
    print("----- FIN -----")
    
# Consultar un alumno por su id
try:
    respuesta = requests.get("http://localhost:3000/alumnos/2")
except:
    print("Ha ocurrido un error")
else:
    if respuesta.status_code == requests.codes.ok:
        print(respuesta.json())
finally:
    print("----- FIN -----")
