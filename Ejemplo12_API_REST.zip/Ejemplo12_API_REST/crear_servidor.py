'''
    Para crear el servidor:
        1.- Descargado e instalado node https://nodejs.org/es/download
        2.- Desde un cmd con permisos de administrador: npm i -g json-server
        3.- Crear el archivo alumnos.json
        4.- En el cmd nos posicionamos donde esta ese archivo alumnos.json
        5.- Publicar el archivo en el servidor: json-server --watch alumnos.json
'''

import requests

respuesta = requests.get("http://localhost:3000")
print(respuesta.status_code) # 200

# Obtener la cebera de la respuesta
print(respuesta.headers)
print(respuesta.headers['content-type'])

print(respuesta.text)