import json
import requests

pedro = {
      "id": "3",
      "nombre": "Pedro",
      "apellido": "Garcia",
      "nota": 5,   # le aprobamos con un 5
      "repetidor": True
    }

cabeceras = {'Content-type': 'application/json'}

try:
    respuesta = requests.put("http://localhost:3000/alumnos/3", headers=cabeceras, data=json.dumps(pedro))
    
    # Volvemos a consultar a Pedro
    nuevo_pedro = respuesta = requests.get("http://localhost:3000/alumnos/3")
except:
    print("Ha ocurrido un error")
else:
    print("Alumno modificado")
    print(nuevo_pedro.json())