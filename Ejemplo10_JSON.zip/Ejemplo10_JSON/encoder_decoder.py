import json

class Persona:
    def __init__(self, nombre, edad):   # constructor de la clase
        self.nombre = nombre
        self.edad = edad

class PersonaEncoder(json.JSONEncoder): # PersonaEncoder hereda de JSONEncoder
    def default(self, objeto):  # sobreescribir el metodo default
        return objeto.__dict__

class PersonaDecoder(json.JSONDecoder):
    def decode(self, objeto):
        diccionario = json.loads(objeto)
        return diccionario

       
lista = list()
# Crear un objeto o instancia de Persona
persona = Persona("Juan", 27)
print(persona)

# Obtener el objeto persona en formato JSON
persona_json = json.dumps(persona, cls=PersonaEncoder)
print(persona_json)  # {"nombre": "Juan", "edad": 27}
print(type(persona_json))  # <class 'str'>

# A traves del objeto JSON obtener el diccionario en Python
persona_python = json.loads(persona_json, cls=PersonaDecoder)
print(persona_python) # {'nombre': 'Juan', 'edad': 27}
print(type(persona_python)) # <class 'dict'>

print("Nombre:", persona_python["nombre"])
print("Edad:", persona_python["edad"])