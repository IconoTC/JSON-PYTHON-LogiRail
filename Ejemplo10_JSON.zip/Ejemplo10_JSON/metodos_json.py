# Para poder trabajar con los json importamos el modulo json
import json

# dumps() -> traduce los datos de Python en JSON
soltero = True
print(json.dumps(soltero)) # true

# con None
print(json.dumps(None)) # null

# con lista de caracteres
print(json.dumps(['a', 'b', 'c'])) # ["a", "b", "c"]

# loads() -> coge un string de JSON y lo tranforma en dato Python
texto_num = "12345.56"
print(json.loads(texto_num)) # 12345.56
print(type(json.loads(texto_num)))  # <class 'float'>

texto = '"Esto es una prueba"'
print(json.loads(texto)) # Esto es una prueba
print(type(json.loads(texto))) # <class 'str'>

lista = '[1, 2.5, true, null, ["a", "b", "c"]]'
print(json.loads(lista))
print(type(json.loads(lista))) # <class 'list'>

objeto = '{"nombre": "Juan", "edad": 47, "cursos":["Python","Java","Angular"]}'
print(json.loads(objeto))
print(type(json.loads(objeto))) # <class 'dict'>