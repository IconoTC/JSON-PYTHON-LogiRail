# tuplas: colecciones ordenadas pero inmutables
# si permite elementos duplicados
# se crean con ()
# Ejemplos de uso: dias de la semana, meses del año, estado civil, puntos cardinales

dias = ("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo")
print(type(dias)) # tuple

# Mostrar todos los elementos
print(dias)

# Recorrer la tupla
for dia in dias:
    print(dia, end=" ")
print("\n-------- FIN --------")

# Mostrar el miercoles
print(dias[2])

# Dime en que indice esta el viernes
print(dias.index('viernes'))

# cuantos lunes hay?
print(dias.count('lunes'))

# Al ser inmutable no me permite eliminar elementos
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]

# Tampoco puedo modificar la tupla
# TypeError: 'tuple' object does not support item assignment
dias[0] = 'otro sabado'