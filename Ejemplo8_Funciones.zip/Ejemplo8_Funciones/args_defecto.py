def datos_trabajador(nombre, estadoCivil="Soltero", sueldo=24000):
    print(nombre, "esta", estadoCivil, "gana", sueldo)
    
datos_trabajador("Juan")
datos_trabajador("Maria", sueldo=37000)

# Puedo cambiar el orden pero hay que poner el nombre del argumento
datos_trabajador(sueldo=37000, nombre="Maria")

def concatenar(*datos, separador=" | "):
    return separador.join(datos)

print(concatenar('a','e','i','o','u'))
print(concatenar('a','e','i','o','u', separador="-"))
print(concatenar('a','e','i','o','u', separador=", "))

# No funciona
#print(concatenar(separador="-", 'a','e','i','o','u'))