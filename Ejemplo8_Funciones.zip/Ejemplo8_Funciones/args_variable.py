# Funcion con un numero variable de argumentos
def sumar(*numeros): # numeros es una tupla
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(1))
print(sumar(1, 9))
print(sumar(1, 9, 5))
print(sumar(1, 9, 5, 7))

'''
    crear una funcion que recibe el nombre y las notas del alumno
    utilizando la funcion sumar() calcular la nota media
    retornar el nombre en mayusculas y la nota media
'''

def procesar_notas(nombre, *notas):
    nota_media = sumar(*notas) / len(notas)
    return nombre.upper(), round(nota_media, 2)

print(procesar_notas('Juan', 3,8,9.2))
print(procesar_notas('Maria', 7.3))
print(procesar_notas('Alfonso', 9,8,9,8.5,10))