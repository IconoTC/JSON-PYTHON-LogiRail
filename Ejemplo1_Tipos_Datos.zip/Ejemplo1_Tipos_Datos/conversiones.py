import math

# convertir string a numero entero
dato = input("Introduce un numero: ")
print(type(dato))  #  str
# Si el valor introducido no es un numero entero genera un ValueError
# ValueError: invalid literal for int() with base 10: 'tres'
# ValueError: invalid literal for int() with base 10: '12.45'
numero1 = int(dato)
print(type(numero1))


# convertir string a numero real
# Todo lo que no sea numero entero o real genera un ValueError
radio = float(input("Introduce radio del circulo (12.45): "))
print("Area del circulo", math.pi * radio ** 2) # ** es una potencia

# redondear numeros
# round(que?, num_decimales)
print("Area del circulo",  round(math.pi * radio ** 2, 2) )

# convertir a texto
print(34, type(str(34)))
print('34.12', type(str(34.12)))
print('True', type(str(True)))

# Los valores booleanos tienen una conversion implicita:
# True -> 1
# False -> 0
numero = 7 + True
print(numero)  # 8