# Operadores aritmeticos (+,-,*,/,%,**,//) 
numero1 = 7
numero2 = 2
print("Suma", numero1 + numero2)
print("Resta", numero1 - numero2)
print("Multiplicacion", numero1 * numero2)
print("Division", numero1 / numero2)  # siempre devuelve numero real (6/2 -> 3.0)
print("Potencia", numero1 ** numero2)
print("Division entera", numero1 // numero2)
print("Resto o modulo de la division", numero1 % numero2)

# Operadores de asignacion (+=,-=,*=,/=,%=,**=,//=) 
num = 8
num += 1    # num = num + 1
print(num)

# En Python no existen los incrementos o decrementos
# num++
# num--
# ++num
# --num

# Operadores de comparación (>,<,>=,<=,==,!=)
print("El numero1 es mayor que numero2", numero1 > numero2)
print("El numero1 es menor que numero2", numero1 < numero2)
print("El numero1 es mayor o igual que numero2", numero1 >= numero2)
print("El numero1 es menor o igual que numero2", numero1 <= numero2)
print("El numero1 es igual que numero2", numero1 == numero2)
print("El numero1 es distinto que numero2", numero1 != numero2)

# Operadores logicos (and,or,not)
print("and", (numero1 > numero2) and numero1 == 7 )
print("and", (numero1 > numero2) and numero1 == 76655 )
print("or", (numero1 > numero2) or numero1 == 76655 )
print("not", not(numero1 == 76655))
print("not", not(numero1 == 7))

# Operadores de identidad (is,is not)
n1 = 6
n2 = 6
print("Es el mismo contenido?", n1 == n2)
print("Es el mismo contenido?", n1 is n2)

nombres1 = ['Juan', 'Maria']
nombres2 = ['Juan', 'Maria']
print("Es el mismo contenido?", nombres1 == nombres2) # True, las listas son iguales
print("Es el mismo contenido?", nombres1 is nombres2) # False, las variables contienen direcciones de memoria distintas

# Operadores de pertenencia (in, not in)
print('Luis' in nombres1) # False
print('Luis' not in nombres1) # True
print('Maria' in nombres1) # True
print('Maria' not in nombres1) # False