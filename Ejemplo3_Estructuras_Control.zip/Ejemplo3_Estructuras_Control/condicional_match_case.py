'''
    Solicitar al usuario la letra del dia de la semana (l,m,x,j,v,s,d)
    puede ser que el usuario lo introduce en mayusculas
    mostrar el dia de la semana al que pertenece
    si la letra no es valida: "Dia no valido"
'''

letra = input("Introduce dia de la semana (l,m,x,j,v,s,d): ")

match letra.lower():
    case 'l':
        print("Es lunes")
    case 'm':
        print("Es martes")
    case 'x':
        print("Es miercoles")
    case 'j':
        print("Es jueves")
    case 'v':
        print("Es viernes")
    case 's':
        print("Es sabado")
    case 'd':
        print("Es domingo")
    case _:
        print("Dia no valido")