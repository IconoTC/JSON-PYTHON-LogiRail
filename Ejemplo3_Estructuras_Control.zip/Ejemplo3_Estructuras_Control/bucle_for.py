# Crear una lista de nombres
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

# por cada elemento que tengo en la lista de nombres:
    # lo mostramos en la consola
for elemento in nombres:
    print(elemento, end=" ")
print("\n---------FIN----------")

"""  rangos   """
# Mostrar los numeros 0 al 9
for numero in range(10): # rango va de 0 a numero-1
    print(numero)
print("---------FIN----------")

# Mostrar los numeros 1 al 10
for numero in range(1,11): # rango va de 1 a numero-1
    print(numero)
print("---------FIN----------")

# Mostrar los numeros 0 al 10 de 2 en 2
for numero in range(0,11,2): # rango va de 0 a numero-1
    print(numero)
print("---------FIN----------")

# Mostrar los numeros -10 al -100 de 10 en 10
for numero in range(-10,-101,-10): # rango va de -10 a numero-1
    print(numero)
print("---------FIN----------")

# Mostrar los numeros -100 al -10 de 10 en 10
for numero in range(-100,-9,10): # rango va de -100 a numero-1
    print(numero)
print("---------FIN----------")

# Mostrar los numeros del 10 al 1 en orden descendente
for numero in range(10,0,-1):
    print(numero)
print("---------FIN----------")

# Las listas tienen una longitud que podemos obtener con la funcion len
print("Longitud de la lista de nombres", len(nombres))  
print("Primer nombre:", nombres[0]) 

for indice in range(len(nombres)):
    print(nombres[indice])
print("---------FIN----------")
 
# Mostrar los nombres de la lista en orden decreciente
for indice in range(len(nombres)-1, -1, -1):
    print(nombres[indice])
print("---------FIN----------")