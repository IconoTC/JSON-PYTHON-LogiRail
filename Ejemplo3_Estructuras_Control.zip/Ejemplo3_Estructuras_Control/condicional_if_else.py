# condicional mas simple
# si se cumple la condicion:
#   se ejecuta este bloque
hora = 10
if hora == 14:
    print("La clase ha terminado")
    
# condicional con alternativa
# si se cumple la condicion:
#   se ejecuta este bloque
# si no se cumple:
#   se ejecuta este otro bloque
if hora == 14:
    print("La clase ha terminado")
else:
    print("Todavia estamos en clase")
    
# condicional anidado
# si se cumple la condicion:
#   se ejecuta este bloque
# si no se cumple probamos con otra condicion y si se cumple:
#   se ejecuta este otro bloque
# si no se cumple probamos con otra condicion y si se cumple:
#   se ejecuta este otro bloque
# si no se cumple ninguna de las anteriores:
#   se ejecuta el ultimo bloque
n1 = 60
n2 = 42
if n1 > n2:
    print("El numero", n1, "es el mayor")
elif n2 > n1:
    print("El numero", n2, "es el mayor")
else:
    print("Los numeros", n1, "y", n2, "son iguales")