# la funcion map, se aplica sobre una coleccion donde
# con cada elemento se invoca a otra funcion que lo modifica
# o devuelve un elemento nuevo
# Importante que la funcion retorne un elemento
# sintaxis:  map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,5,14,28]

def duplicar(numero):
    return numero * 2

numeros_dobles = list(map(duplicar, numeros))
print(numeros_dobles)
print(numeros) # La coleccion original no se modifica


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

def subir_punto(item):
    return item[0], item[1] + 1

nuevas_notas = dict(map(subir_punto, alumnos.items()))
print(nuevas_notas)