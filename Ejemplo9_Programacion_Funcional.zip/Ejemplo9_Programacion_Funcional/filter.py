# la funcion filter se aplica sobre una coleccion
# a través de otra funcion filtramos los elementos
# La funcion tiene que devolver una valor booleano:
#   - True: pasa el filtro y nos lo quedamos
#   - False: no pasa el filtro y lo descartamos
# sintaxis: filter(funcion, coleccion)

# Importar el archivo map.py
import map

# Ejemplo 1
numeros = [3,8,5,14,28]

def pares(numero):
    # return numero % 2 == 0
    if numero % 2 == 0:
        return True
    else:
        return False
  
#numeros_pares = list(filter(pares, numeros))
# Recuperas la lista de numeros
numeros_pares = list(filter(pares, map.numeros))
print(numeros_pares)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=3.1)

def suspensos(item):
    #return item[1] < 5
    if  item[1] < 5:
        return True
    else:
        return False
    
alumnos_suspensos = dict(filter(suspensos, alumnos.items()))
print(alumnos_suspensos)