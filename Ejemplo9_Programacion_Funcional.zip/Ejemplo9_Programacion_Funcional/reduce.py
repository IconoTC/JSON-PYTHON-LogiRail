# la funcion reduce le pasamos una coleccion
# y retorna un solo resultado
# La funcion ha de tener 2 parametros:
#   - el primero actua como acumulador
#   - el segundo es el valor recibido
# sintaxis: reduce(funcion, coleccion)

''' Para utilizar reduce hay que importarlo '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,5,14,28]

def sumar(acumulado, num):
    # la primera vez que se invoca se le pasan 2 argumentos: 3, 8
    return acumulado + num

print("Suma:", reduce(sumar, numeros))

# Ejemplo 2
nombres = ['Juan', 'Maria', 'Pedro', 'Luis']

# funcion concatenar que me retorne todos los nombres separados " - "
def concatenar(acumulado, nombre):
    return acumulado + " - " + nombre

print(reduce(concatenar, nombres))