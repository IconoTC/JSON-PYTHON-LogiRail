import json
import requests

try:
    # aqui metemos el codigo que puede dar error
    nombre = input("Introduce el nombre del pokemon: ")
    respuesta = requests.get("https://pokeapi.co/api/v2/pokemon/"+nombre)
except:
    # si ha ocurrido un error aqui lo procesamos
    print("Ha ocurrido un error")
else:
    # si no ha ocurrido ningun error
    if respuesta.status_code == requests.codes.ok:
        datos = respuesta.json()
        print("ID:", datos['id'])
        print("Nombre:", datos['name'])
        print("Peso:", datos['weight'])
        print("Altura:", datos['height'])
        print("Habilidades:")
        for habilidad in datos['abilities']:
            print("\t", habilidad['ability']['name'])
            
        for moves in datos['moves']:
            for item in moves['version_group_details']:
                print(item['level_learned_at'])
finally:
    # se ejecuta simpre haya errores o no
    print("------ FIN ------")