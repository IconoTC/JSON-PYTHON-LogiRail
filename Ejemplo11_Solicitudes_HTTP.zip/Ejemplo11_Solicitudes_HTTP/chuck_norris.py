import json
import requests

try:
    # aqui metemos el codigo que puede dar error
    respuesta = requests.get("https://api.chucknorris.io/jokes/random")
except:
    # si ha ocurrido un error aqui lo procesamos
    print("Ha ocurrido un error")
else:
    # si no ha ocurrido ningun error
    if respuesta.status_code == requests.codes.ok:
        print(respuesta.json()['value'])
finally:
    # se ejecuta simpre haya errores o no
    print("------ FIN ------")