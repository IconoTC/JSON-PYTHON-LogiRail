# conjuntos: colecciones sin orden, no usamos indices
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Se crean utilizando: {}
# CUIDADO: conjunto={} se interpreta como un diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas)) # set

# crear un conjunto vacio
conjunto = set()

# Mostrar el conjunto vemos los duplicados los ignora
print(frutas)

# agregar fresas
frutas.add('fresas')
print(frutas)

# eliminar el platano
# del borra por posicion
frutas.remove("platano")
print(frutas)

# longitud
print(len(frutas))

# Recorrer conjuntos
for fruta in frutas:
    print(fruta, end=" ")
print()

# Borrar todos los elementos
frutas.clear()
print(frutas)