texto = "bienvenidos al curso de Python"

print(texto)

# Poner la primera letra de la frase en mayuscula
print(texto.capitalize())

# Poner la primera letra de cada palabra en mayuscula
print(texto.title())

# frase en mayusculas
print(texto.upper())

# frase en minisculas
print(texto.lower()) 

# Retornar un valor booleano que indica si la cadena es alfanumerica (letras y numeros)
print(texto.isalnum()) # False por los espacios en blanco
print("texto1234".isalnum()) # True

# Retornar un valor booleano que indica si la cadena es alfabetica (letras)
print(texto.isalpha()) # False por los espacios en blanco
print("texto".isalpha()) # True

# Retornar un valor booleano que indica si la cadena son digitos (numeros)
print(texto.isdigit()) # False por los espacios en blanco y  letras
print("12345".isdigit()) # True

# Retornar un valor booleano que indica si la cadena son minusculas (ignora los espacios en blanco y otros caracteres)
print(texto.islower()) # False por la letra P de Python
print("hola".islower()) # True
print("hola caracola".islower()) # True

# Retornar un valor booleano que indica si la cadena son mayusculas (ignora los espacios en blanco y otros caracteres)
print(texto.isupper()) # False por la letra P de Python
print("HOLA".isupper()) # True
print("HOLA, QUE TAL?".isupper()) # True

# lstrip -> elimina espacios en blanco por la izquierda
# rstrip -> elimina espacios en blanco por la derecha
# strip -> elimina espacios en blanco por la izquierda y derecha
ejemplo = "    hola, como estas?      "
print(ejemplo.lstrip(), end=".\n")   # Por defecto elimina espacios
print("---hola---".lstrip('-'), end=".\n")   # Elimina -

print(ejemplo.rstrip(), end=".\n")
print(ejemplo.strip(), end=".\n")

# Longitud de las cadenas
print("Longitud:", len(texto))
print("Longitud:", texto.__len__())  # __xxxx recurso privado

# Caracter con mayor posicion en la tabla ASCII
# El orden en la tabla es: digitos, mayusculas, minusculas
print("Max:", max(texto))

# Caracter con menor posicion en la tabla ASCII
print("Min:", min(texto))

# Reemplazar 
print(texto.replace('e', 'E'))  # reemplaza todas
print(texto.replace('Python', 'Angular'))
print(texto.replace('e', 'E', 2)) # reemplaza las 2 primeras
print(texto.replace('e', 'E', -2)) # reemplaza todas

# Trocear el texto por el espacio y devolver los fragmentos en una lista
print("palabras: ", texto.split()) # por defecto es el espacio en blanco
print("21/4/2025".split('/'))

# Intercambiar mayusculas por minusculas y viceversa
print(texto.swapcase())

# contar cuantas letras o tengo en el texto
print("Cuantas o?", texto.count('o'))
print("Cuantas o a partir del indice 20?", texto.count('o', 20))
print("Cuantas o entre el indice 8 y 20?", texto.count('o', 8, 20))

# Devuelve un valor booleano indicando si la cadena comienza por ese caracter o texto
print(texto.startswith('b')) # True
print(texto.startswith('B')) # False
print(texto.startswith('bienvenidos')) # True

# Devuelve un valor booleano indicando si la cadena termina por ese caracter o texto
print(texto.endswith('n')) # True
print(texto.endswith('N')) # False
print(texto.endswith('Python')) # True

# find buscar una caracter por la izquierda y retorna la posicion
# rfind buscar un caracter por la derecha
print("Primera letra a:", texto.find('a'))
print("Primera letra a a partir del indice 5:", texto.find('a', 5))
print("Primera letra a entre el indice 5 y 20:", texto.find('a', 5, 20))

print("Primera letra o:", texto.find('o')) # Empieza a buscar por la izquierda
print("Ultima letra o:", texto.rfind('o')) # Empieza a buscar por la derecha

# devolver una lista con las palabras en mayusculas
contenido = "    Esto es una prueba de conceptos     "
print(contenido.strip().upper().split() )
contenido = contenido.strip()
contenido = contenido.upper()
contenido = contenido.split()
print(contenido)