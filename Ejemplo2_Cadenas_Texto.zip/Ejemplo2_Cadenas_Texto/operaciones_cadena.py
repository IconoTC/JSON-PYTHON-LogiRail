# operadores de pertenencia (in, not in)
texto = "bienvenidos al curso de Python"
print('W' in texto) # False
print('W' not in texto) # True
print('P' in texto) # True

# multiplicar cadenas
print('-' * 20)

# Centrar textos
print("hola".center(40), end=".\n")