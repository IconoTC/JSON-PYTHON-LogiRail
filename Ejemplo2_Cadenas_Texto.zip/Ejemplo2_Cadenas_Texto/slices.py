# Las cadenas de texto se consideran listas de caracteres

# slices [inicio:final:step]
texto = "bienvenidos al curso de Python"

# Mostrar solo la palabra bienvenidos 
print(texto[0:11])  # la ultima posicion no esta incluida
print(texto.find(" "))
print(texto[0:texto.find(" ")])

# Mostrar solo la palabra Python
print(texto[texto.find("P"):texto.__len__()])
print(texto[texto.find("P"):])  # Si no indico el final incluye todo
print(texto[-6:])
print(texto[24:])

# Mostrar solo la palabra curso
print(texto[texto.find("c"):texto.find(" ", texto.find("c"))])

# Mostrar todas la letras
print(texto[0: len(texto)])
print(texto[:])
print(texto[0:])

# Mostrar todas la letras en orden inverso
print(texto[:: -1])

# Mostrar todas la letras de 2 en 2
print(texto[::2])