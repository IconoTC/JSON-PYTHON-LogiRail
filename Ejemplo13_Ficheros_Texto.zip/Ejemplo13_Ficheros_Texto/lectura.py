# Abrir el fichero en modo lectura
fichero = open("Ejemplo13_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Leer todo el contenido del fichero
texto = fichero.read()
print(texto)

# mover el cursor o puntero al primer caracter
fichero.seek(0)

# leer todas las lineas y guardarlas en una lista
lista = fichero.readlines()
for linea in lista:
    print(linea, end="")
    
# leer todas las lineas y guardarlas en una lista
fichero.seek(0)
lista = list(fichero) 
for linea in lista:
    print(linea, end="")
    
fichero.close()